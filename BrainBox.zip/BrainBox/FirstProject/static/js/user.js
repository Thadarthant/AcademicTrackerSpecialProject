document.addEventListener("DOMContentLoaded", function() {
  // --- Navigation ---
  const navItems = document.querySelectorAll(".nav-link");
  const sections = document.querySelectorAll(".main-content");
  if(document.getElementById("Home")) document.getElementById("Home").style.display = "block";

  navItems.forEach(item => {
    item.addEventListener("click", function() {
      navItems.forEach(link => link.classList.remove("active"));
      this.classList.add("active");

      sections.forEach(sec => sec.style.display = "none");

      const sectionId = this.getAttribute("data-section");
      const target = document.getElementById(sectionId);
      if(target) target.style.display = "block";
    });
  });

  // --- Notification Bell ---
  const bellIcon = document.getElementById("bellIcon");
  const notifDropdown = document.getElementById("notifDropdown");
  const closeNotif = document.getElementById("closeNotif");

  if(bellIcon && notifDropdown) {
    bellIcon.addEventListener("click", function(e){
      e.stopPropagation();
      notifDropdown.style.display = getComputedStyle(notifDropdown).display === "none" ? "block" : "none";
    });

    if(closeNotif) closeNotif.addEventListener("click", () => { notifDropdown.style.display = "none"; });

    document.addEventListener("click", function(e){
      if(!bellIcon.contains(e.target) && !notifDropdown.contains(e.target)) {
        notifDropdown.style.display = "none";
      }
    });
  }

  // --- Profile Dropdown ---
  const profileDropdown = document.getElementById("profileDropdown");
  const dropdownMenu = document.getElementById("dropdownMenu");
  if(profileDropdown && dropdownMenu){
    profileDropdown.addEventListener("click", (e) => {
      e.stopPropagation();
      dropdownMenu.style.display = getComputedStyle(dropdownMenu).display === "block" ? "none" : "block";
    });
    document.addEventListener("click", () => { dropdownMenu.style.display = "none"; });
  }

  // --- Profile Photo ---
  const profilePhotoInput = document.getElementById("profilePhotoInput");
  const profileImage = document.getElementById("profileImage");
  const topbarProfile = document.getElementById("topbarProfile");

  if(profilePhotoInput){
    profilePhotoInput.addEventListener("change", (e) => {
      const file = e.target.files[0];
      if(file){
        const reader = new FileReader();
        reader.onload = (ev) => {
          if(profileImage) profileImage.src = ev.target.result;
          if(topbarProfile) topbarProfile.src = ev.target.result;
        };
        reader.readAsDataURL(file);
      }
    });
  }

  // --- Level Selection ---
  const levelOptions = document.querySelectorAll(".level-option");
  levelOptions.forEach(option => {
    option.addEventListener("click", function(){
      levelOptions.forEach(opt => opt.classList.remove("selected"));
      this.classList.add("selected");
      const selectedLevel = this.getAttribute("data-level");
      filterCoursesByLevel(selectedLevel);
    });
  });

});

// Course functions
window.startCourse = function (courseName) {
  alert("Now starting: " + courseName);
};

// Course data
const coursesData = [
  {
    title: "Intro to HTML",
    description: "Learn the basics of HTML to build web pages.",
    image: "images/html.jpg",
    levels: ["beginner"],
    rating: 4,
  },
  {
    title: "CSS Essentials",
    description: "Master styling and responsive design.",
    image: "images/Css.jpg",
    levels: ["beginner", "intermediate"],
    rating: 4,
  },
  {
    title: "JavaScript Basics",
    description: "Make your websites interactive.",
    image: "images/java.jpg",
    levels: ["beginner", "intermediate"],
    rating: 4,
  },
  {
    title: "Python Basic",
    description: "Build your foundation in Python.",
    image: "images/python.jpg",
    levels: ["beginner"],
    rating: 4,
  },
  {
    title: "Advanced JavaScript",
    description: "Deep dive into JS frameworks.",
    image: "images/java.jpg",
    levels: ["intermediate", "advanced"],
    rating: 5,
  },
];

// Filter courses by level
function filterCoursesByLevel(level) {
  const filteredCourses = coursesData.filter((course) =>
    course.levels.includes(level)
  );

  const coursesContainer = document.getElementById("filtered-courses");
  coursesContainer.innerHTML = "";

  if (filteredCourses.length === 0) {
    coursesContainer.innerHTML = "<p>No courses found for this level.</p>";
    return;
  }

  // Create a card container div
  const cardContainer = document.createElement("div");
  cardContainer.className = "card-container";

  filteredCourses.forEach((course) => {
    const courseCard = document.createElement("div");
    courseCard.className = "course-card";
    courseCard.innerHTML = `
      <div class="card-photo">
        <img src="/static/${course.image}" alt="${course.title}" class="course-image">
      </div>
      <div class="card-content">
        <h3>${course.title}</h3>
        <p>${course.description}</p>
        <button onclick="startCourse('${course.title}')">Start</button>
        <div class="rating">
          ${renderRatingStars(course.rating)}
        </div>
      </div>
    `;
    cardContainer.appendChild(courseCard);
  });

  coursesContainer.appendChild(cardContainer);
}

// Render rating stars
function renderRatingStars(rating) {
  let starsHTML = "";
  for (let i = 1; i <= 5; i++) {
    if (i <= rating) {
      starsHTML += '<i class="fas fa-star"></i>';
    } else if (i - 0.5 <= rating) {
      starsHTML += '<i class="fas fa-star-half-alt"></i>';
    } else {
      starsHTML += '<i class="far fa-star"></i>';
    }
  }
  return starsHTML;
}
function showSection(sectionId) {
  // Hide all sections
  document.querySelectorAll(".page-section").forEach((section) => {
    section.style.display = "none";
  });

  // Show selected section
  document.getElementById(sectionId).style.display = "block";
}
function getInitials(name) {
  if (!name) return "";
  return name
    .split(" ")
    .map((n) => n[0])
    .join("")
    .toUpperCase();
}
// Navigation click handler
document.querySelectorAll(".nav-link").forEach((link) => {
  link.addEventListener("click", function () {
    showSection(this.getAttribute("data-section"));
  });
  
});

// About us //
function toggleFeedback(id) {
  const box = document.getElementById(id);
  box.style.display = (box.style.display === "block") ? "none" : "block";
}

function logout() {
  alert("You have been logged out.");
  window.location.href = "{% url 'logout' %}";
}

function toggleFeedback(feedbackId) {
  // Hide all feedback lists first
  document.querySelectorAll('#About-us .feedback-list').forEach(el => {
    if (el.id !== feedbackId) el.style.display = 'none';
  });
  // Toggle selected feedback
  const el = document.getElementById(feedbackId);
  el.style.display = (el.style.display === 'block') ? 'none' : 'block';
}

// lesson complete
function markLessonCompleted(lessonId) {
  fetch(`/lesson/${lessonId}/complete/`, {
    method: 'POST',
    headers: {
      'X-CSRFToken': '{{ csrf_token }}',
      'Content-Type': 'application/json'
    }
  })
  .then(res => res.json())
  .then(data => {
    alert(`Progress updated: ${data.completion_percentage}%`);
    location.reload();
  });
}

//close notification
const closeNotif = document.getElementById("closeNotif");

closeNotif.addEventListener("click", () => {
  notifDropdown.style.display = "none";
});

//profile
const profilePhotoInput = document.getElementById("profilePhotoInput");
const profileImage = document.getElementById("profileImage");
const topbarProfile = document.getElementById("topbarProfile");

if(profilePhotoInput) {
  profilePhotoInput.addEventListener("change", (e) => {
    const file = e.target.files[0];
    if(file) {
      const reader = new FileReader();
      reader.onload = (ev) => {
        if(profileImage) profileImage.src = ev.target.result;
        if(topbarProfile) topbarProfile.src = ev.target.result;
      };
      reader.readAsDataURL(file);
    }
  });
}


// --- Edit Profile ---
function toggleEditMode() {
  const inputs = document.querySelectorAll(
    "#settingsForm input, #settingsForm select"
  );
  const saveBtn = document.getElementById("saveBtn");
  const cancelBtn = document.getElementById("cancelBtn");

  
  inputs.forEach((input) => {
    input.disabled = !input.disabled;
  });

  
  if (saveBtn.style.display === "none" || saveBtn.style.display === "") {
    saveBtn.style.display = "inline-block";
    cancelBtn.style.display = "inline-block";
  } else {
    saveBtn.style.display = "none";
    cancelBtn.style.display = "none";
  }
}

// Cancel button 
function cancelEdit() {
  const inputs = document.querySelectorAll(
    "#settingsForm input, #settingsForm select"
  );
  inputs.forEach((input) => {
    input.disabled = true;
  });

  document.getElementById("saveBtn").style.display = "none";
  document.getElementById("cancelBtn").style.display = "none";
}


