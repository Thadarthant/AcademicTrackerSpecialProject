from django.contrib import admin
from django.urls import path, include  # ✅ This line is essential
from django.conf import settings
from django.conf.urls.static import static

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', include('Home.urls')),  # ✅ This assumes Home/urls.py is correctly set up
]

if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
