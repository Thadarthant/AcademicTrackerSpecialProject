# views.py
from django.shortcuts import render, redirect, get_object_or_404
from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.http import  HttpResponse
from django.urls import reverse


# Home page
def home_view(request):
    return render(request, 'user.html')

# Course progress page
# views.py
from django.shortcuts import render
from .models import Feedback

# Dashboard / Progress page
def dashboard(request):
    # Example courses progress data
    user_courses = [
        {'name': 'HTML', 'progress': 80},
        {'name': 'CSS', 'progress': 60},
        {'name': 'JavaScript', 'progress': 45},
    ]

    feedbacks = Feedback.objects.all().order_by('-created_at')
    
    context = {
        'user_courses': user_courses,
        'feedbacks': feedbacks,
    }
    
    return render(request, "user.html", context)



# Submit feedback
def submit_feedback(request):
    if request.method == "POST":
        name = request.POST.get('name')
        email = request.POST.get('email')
        rating = request.POST.get('rating')
        courses = request.POST.get('courses')
        comments = request.POST.get('comments')
        user_type = request.POST.get('user_type', 'student')

        Feedback.objects.create(
            name=name,
            email=email,
            rating=rating,
            courses=courses,
            comments=comments,
            user_type=user_type
        )

        return redirect('feedback_success')


# Feedback success alert
def feedback_success(request):
    url = reverse('feedback_list')
    return HttpResponse(f"""
        <script>
            alert('✅ Thank you for your feedback!');
            window.location.href = '{url}';
        </script>
    """)


# List all feedbacks
def feedback_list(request):
    feedbacks = Feedback.objects.all()
    return render(request, 'feedback_list.html', {'feedbacks': feedbacks})


# Delete feedback
def delete_feedback(request, feedback_id):
    feedback = get_object_or_404(Feedback, id=feedback_id)
    feedback.delete()
    messages.success(request, "Feedback deleted successfully!")
    return redirect('feedback_list')


# Edit feedback
def edit_feedback(request, feedback_id):
    feedback = get_object_or_404(Feedback, id=feedback_id)

    if request.method == "POST":
        feedback.name = request.POST.get('name')
        feedback.email = request.POST.get('email')
        feedback.rating = request.POST.get('rating')
        feedback.courses = request.POST.get('courses')
        feedback.comments = request.POST.get('comments')
        feedback.user_type = request.POST.get('user_type', 'student')
        feedback.save()

        messages.success(request, "Feedback updated successfully!")
        return redirect('feedback_list')

    return render(request, 'edit_feedback.html', {'feedback': feedback})


# About us page with feedbacks
def about_us(request):
    feedbacks = Feedback.objects.all()
    return render(request, "about_us.html", {"feedbacks": feedbacks})


# Courses page
def course_list(request):
    courses = Course.objects.all()
    return render(request, 'courses.html', {'courses': courses})

#feedback

from django.shortcuts import render
from .models import Course, Feedback

def dashboard(request):
    feedbacks = Feedback.objects.all().order_by('-created_at')
    return render(request, "user.html", {"feedbacks": feedbacks})

# Home/views.py
from django.shortcuts import render
from .models import Feedback

def get_feedback(request, type=None):
    feedbacks = Feedback.objects.all().order_by('-created_at')
    return render(request, "feedback_list.html", {"feedbacks": feedbacks})

#feedback_list

from django.shortcuts import render
from .models import StudentFeedback

def student_feedback_list(request):
    feedbacks = StudentFeedback.objects.all().order_by("-created_at")
    return render(request, "feedback/student_feedback_list.html", {"feedbacks": feedbacks})

# views.py
from django.shortcuts import render
from Home.models import Feedback

def about_us(request):
    feedbacks_students = Feedback.objects.filter(user_type='student').order_by('-created_at')
    feedbacks_teachers = Feedback.objects.filter(user_type='teacher').order_by('-created_at')
    feedbacks_admin = Feedback.objects.filter(user_type='admin').order_by('-created_at')

    return render(request, 'user.html', {
        'feedbacks_students': feedbacks_students,
        'feedbacks_teachers': feedbacks_teachers,
        'feedbacks_admin': feedbacks_admin,
    })

# Home/views.py
from django.shortcuts import render, redirect
from django.http import HttpResponse

def submit_assignment(request):
    if request.method == "POST":
        student_name = request.POST.get("student_name")
        email = request.POST.get("email")
        course = request.POST.get("course")
        comments = request.POST.get("comments")
        assignment_file = request.FILES.get("assignment_file")

        return HttpResponse(f"Assignment submitted by {student_name} for {course}!")

    return HttpResponse("Invalid request")

#grade
from django.shortcuts import render, redirect

# Grade page ကို ပြရန် view
def grade_page(request):
   
    return render(request, 'grade.html')
# Grade form submit လုပ်ရန် view
def submit_grade(request):
    if request.method == "POST":
        student_name = request.POST.get("student_name")
        course = request.POST.get("course")
        grade = request.POST.get("grade")
        comments = request.POST.get("comments")
        # database save logic ရှိရင် ဒီမှာရေးနိုင်သည်

        return redirect('grade_page')  # grade_page URL name သို့ redirect
    return render(request, 'grade.html')

#my grade
from django.shortcuts import render
from .models import Grade

def my_grades(request):
    student_name = "John Doe"  # Example student name, change as needed
    grades = Grade.objects.filter(student_name=student_name)  
    return render(request, 'my_grades.html', {'grades': grades})

#progress