from django.urls import path
from . import views

urlpatterns = [
    path('', views.home_view, name='home'),
    path('submit-feedback/', views.submit_feedback, name='submit_feedback'),
    path('feedback/success/', views.feedback_success, name='feedback_success'),
    path('feedback-list/', views.feedback_list, name='feedback_list'),
    path('feedback/delete/<int:feedback_id>/', views.delete_feedback, name='delete_feedback'),
    path('feedback/edit/<int:feedback_id>/', views.edit_feedback, name='edit_feedback'),
    path('courses/', views.course_list, name='course_list'),
    path('get-feedback/<str:type>/', views.get_feedback, name='get_feedback'),
    path('about-us/', views.about_us, name='about_us'),
    path("submit-feedback/", views.submit_feedback, name="submit_feedback"),
    path("students-feedback/", views.student_feedback_list, name="students_feedback"),
    path('assignment/submit/', views.submit_assignment, name='submit_assignment'),
    path('grade/submit/', views.submit_grade, name='submit_grade'),
    path('grade/', views.grade_page, name='grade_page'),
    path('my-grades/', views.my_grades, name='my_grades'),
    

]