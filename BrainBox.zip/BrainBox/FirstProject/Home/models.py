from django.db import models
from django.contrib.auth.models import User

# Profile Model

class Profile(models.Model):
    name = models.CharField(max_length=100)
    photo = models.ImageField(upload_to='profile_photos/')


    def __str__(self):
        return self.user.username

# Course Model
class Course(models.Model):
    title = models.CharField(max_length=255)
    description = models.TextField()

    def __str__(self):
        return self.title

# Lesson Model
class Lesson(models.Model):
    course = models.ForeignKey(Course, on_delete=models.CASCADE, related_name='lessons')
    title = models.CharField(max_length=255)
    content = models.TextField()

    def __str__(self):
        return self.title

# Lesson Progress
class LessonProgress(models.Model):
    student = models.ForeignKey(User, on_delete=models.CASCADE)
    lesson = models.ForeignKey(Lesson, on_delete=models.CASCADE)
    completed = models.BooleanField(default=False)

# Feedback Model
class Feedback(models.Model):
    USER_TYPES = (
        ('student', 'Student'),
        ('teacher', 'Teacher'),
        ('admin', 'Admin'),
    )
    name = models.CharField(max_length=255)
    email = models.EmailField()
    rating = models.IntegerField()
    courses = models.CharField(max_length=255, blank=True)
    comments = models.TextField(blank=True)
    user_type = models.CharField(max_length=20, choices=USER_TYPES, default='student')
    created_at = models.DateTimeField(auto_now_add=True)

# Assignment Model
class Assignment(models.Model):
    title = models.CharField(max_length=255)
    file = models.FileField(upload_to='assignments/')
    submitted_by = models.ForeignKey(User, on_delete=models.CASCADE)
    submitted_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.title

class StudentFeedback(models.Model):
    student = models.ForeignKey(Profile, on_delete=models.CASCADE)
    feedback = models.TextField()
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"Feedback by {self.student}"
    
#grade/subject models

from django.db import models

class Grade(models.Model):
    student_name = models.CharField(max_length=100)
    course = models.CharField(max_length=100)
    grade = models.CharField(max_length=5)
    comments = models.TextField(blank=True, null=True)

    def __str__(self):
        return f"{self.student_name} - {self.course}"

#progress model
