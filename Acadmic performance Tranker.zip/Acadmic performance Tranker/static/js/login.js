// Password toggle functionality
document.addEventListener('DOMContentLoaded', function() {
  const togglePasswordBtn = document.getElementById('togglePassword');
  const passwordInput = document.getElementById('password');
  
  if (togglePasswordBtn && passwordInput) {
    togglePasswordBtn.addEventListener('click', function() {
      const type = passwordInput.getAttribute('type') === 'password' ? 'text' : 'password';
      passwordInput.setAttribute('type', type);
      
      // Toggle eye icon
      const eyeIcon = this.querySelector('i');
      if (type === 'password') {
        eyeIcon.classList.remove('fa-eye-slash');
        eyeIcon.classList.add('fa-eye');
      } else {
        eyeIcon.classList.remove('fa-eye');
        eyeIcon.classList.add('fa-eye-slash');
      }
    });
  }
  
  // Form submission
  const loginForm = document.querySelector('.login-form');
  if (loginForm) {
    loginForm.addEventListener('submit', function(e) {
      e.preventDefault();
      
      const studentId = this.querySelector('input[type="text"]').value;
      const password = this.querySelector('#password').value;
      const rememberMe = this.querySelector('#remember').checked;
      
      // Simple validation
      if (!studentId.trim()) {
        alert('Please enter your Student ID');
        return;
      }
      
      if (!password.trim()) {
        alert('Please enter your password');
        return;
      }
      
      // Show loading state
      const loginBtn = this.querySelector('.login-btn');
      const originalText = loginBtn.innerHTML;
      
      loginBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Logging in...';
      loginBtn.disabled = true;
      
      // Simulate login process (replace with actual API call)
      setTimeout(() => {
        // Simulate successful login
        alert(`Welcome back, Student ${studentId}! ${rememberMe ? 'Your login will be remembered.' : ''}`);
        
        // Reset button
        loginBtn.innerHTML = originalText;
        loginBtn.disabled = false;
        
        // In a real app, you would redirect to dashboard here
        // window.location.href = '/dashboard';
      }, 1500);
    });
  }
  
  // Social login buttons
  const googleBtn = document.querySelector('.google-btn');
  const microsoftBtn = document.querySelector('.microsoft-btn');
  
  if (googleBtn) {
    googleBtn.addEventListener('click', function() {
      alert('Google login would be implemented here');
      // window.location.href = '/auth/google';
    });
  }
  
  if (microsoftBtn) {
    microsoftBtn.addEventListener('click', function() {
      alert('Microsoft login would be implemented here');
      // window.location.href = '/auth/microsoft';
    });
  }
  
  // Sign up link
  const signupLink = document.querySelector('.signup');
  if (signupLink) {
    signupLink.addEventListener('click', function(e) {
      e.preventDefault();
      alert('Sign up page would open here');
      // window.location.href = '/signup';
    });
  }
  
  // Forgot password link
  const forgotPasswordLink = document.querySelector('.forgot-password');
  if (forgotPasswordLink) {
    forgotPasswordLink.addEventListener('click', function(e) {
      e.preventDefault();
      alert('Password reset page would open here');
      // window.location.href = '/forgot-password';
    });
  }
});