from django.urls import path

from accounts import views


urlpatterns = [
    path('', views.login_view, name='login'),
]
